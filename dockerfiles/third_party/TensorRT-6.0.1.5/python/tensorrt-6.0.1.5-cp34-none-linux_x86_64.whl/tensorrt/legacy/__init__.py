# This file provides a way to maintain support for legacy bindings before deprecating them.
# Also expose the new API when this file is imported.
from tensorrt import *

from . import infer
from . import parsers
from . import lite
from . import utils
__version__ = "6.0.1.5"
